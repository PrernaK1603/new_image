var gulp = require("gulp");
var spritesmith = require("gulp.spritesmith");
var imagemin = require("gulp-imagemin");
var fs = require("fs");
var jsonImg = JSON.parse(fs.readFileSync("./config/config.json"));

/*function minify_image(done) {
    gulp
    .src("src/assets/image/*.png")
    .pipe(imagemin())
    .pipe(gulp.dest("temp/assets/image"));
    done();
}

function image_sprite(done) {
  var spriteData = gulp.src("src/assets/image/*.*").pipe(
    spritesmith({
      imgName: "sprite.png",
      cssName: "sprite.scss"
    })
  );
  spriteData.img.pipe(gulp.dest("temp/src/image"));
  spriteData.css.pipe(gulp.dest("temp/src/image"));
  done();
}*/

/*function image_sprite(done) {
  for (var i = 0; i < json_img.images.length; i++) {
    for (var j = 0; j < json_img.images[i].src_img.length; j++) {
      const path=json_img.images[i].src_dir + json_img.images[i].src_img[j]
      var spriteData = gulp.src(path).pipe(
        spritesmith({
          imgName: json_img.images[i].temp_img,
          cssName: json_img.images[i].temp_scss
        })
      );
      spriteData.img.pipe(gulp.dest(json_img.images[i].temp_img_dir));
      spriteData.css.pipe(gulp.dest(json_img.images[i].temp_scss_dir));
      done();
    }
  }
}

function minify_image(done) {
  for (var i = 0; i < json_img.images.length; i++) {
    for (var j = 0; j < json_img.images[i].src_img.length; j++) {
      const path=json_img.images[i].src_dir + json_img.images[i].src_img[j]
      gulp
    .src(path)
    .pipe(imagemin())
    .pipe(gulp.dest(json_img.images[i].temp_img_dir));
      done();
    }
  }
}*/

/* Change the directory after optimize the image*/

function imageArray(currTask, temp) {
  let files = [];
  let currPath = temp || currTask.srcDir;
  for (var k = 0; k < currTask.srcImg.length; k++) {
    files.push(currPath + currTask.srcImg[k]);
  }
  return files;
}

function minifyImage(currTask, temp) {
  let files = imageArray(currTask, temp);
  gulp
    .src(files)
    .pipe(imagemin())
    .pipe(gulp.dest(currTask.tempImgDir));
  temp = currTask.tempImgDir;
  let path = [
    {
      fileFilter: temp
    }
  ];
  return path;
}

function imageSprite(currTask, temp) {
  let files = imageArray(currTask, temp);
  let spriteData = gulp.src(files).pipe(
    spritesmith({
      imgName: currTask.tempImg,
      cssName: currTask.tempScss
    })
  );
  spriteData.img.pipe(gulp.dest(currTask.tempImgDir));
  spriteData.css.pipe(gulp.dest(currTask.tempScssDir));
  temp = currTask.tempImgDir;
  //console.log(path);
  let path = [
    {
      fileFilter: temp
    },
    {
      fileFilter: temp
    }
  ];
  return path;
}

/* Distribution Function*/

function dist(d, currTask) {
  for (var k = 0; k < d.length; d++) {
    console.log(d[k].fileFilter + "*.*");
    gulp.src(d[k].fileFilter + "*.*").pipe(gulp.dest(currTask.dist));
  }
  return;
}

/*Call both functions i.e minify_image and image_sprite*/

function loopTasks(done) {
  for (let i = 0; i < jsonImg.images.length; i++) {
    let storeObj = jsonImg.images[i].tasks;
    var currTask = jsonImg.images[i];
    let temp = "";
    if (storeObj == undefined) {
      console.log("Entered an incorrect task, Please enter a correct task");
    } else {
      for (var j = 0; j < storeObj.length; j++) {
        let strFunc = storeObj[j];
        if (strFunc == "minifyImage") {
          var d = minifyImage(currTask, temp);
        } else if (strFunc == "imageSprite") {
          d = imageSprite(currTask, temp);
        }
        //console.log(d);
      }
      /*fs.access("./temp/assets/image/", function(error) {
        if (error) {
          console.log("Directory does not exist.");
        } else {
          dist(d, currTask);
        }
      });*/
    }
  }

  fs.access("./temp/assets/image/", function(error) {
    if (error) {
      console.log("Directory does not exist.");
    } else {
      dist(d, currTask);
    }
  });
  done();
}

// const imageTasks = gulp.series(minify_image,image_sprite);

const imageTasks = gulp.series(loopTasks);
exports.imageTasks = imageTasks;

//gulp.task("sprites", image_sprite);

//gulp.task("optimize", minify_image);
